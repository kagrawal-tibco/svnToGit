Props:
benchmark.noiseconfig=A/number,B/number...E/number
benchmark.cardswipeconfig=number (TPS)