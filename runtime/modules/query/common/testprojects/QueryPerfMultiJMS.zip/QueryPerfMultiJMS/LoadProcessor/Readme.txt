Props: 
benchmark.query.selectcardswipe.output.dir
benchmark.query.selectcardswipe.numqueries

benchmark.query.selectcardswipewinavg.output.dir
benchmark.query.selectcardswipewinavg.numqueries