/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Formatter;

/**
 *
 * @author ajayapra
 */
public class Temp {

    public static void main(String[] args) {
        System.out.println(new Formatter().format("%034d", 10L));
    }
}
