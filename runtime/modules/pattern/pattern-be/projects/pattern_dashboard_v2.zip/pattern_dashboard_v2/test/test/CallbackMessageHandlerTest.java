/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.tibco.cep.pattern.dashboard.control.callback.DefaultCallbackMessageHandler;
import com.tibco.cep.pattern.dashboard.vo.callback.PatternResult;
import javax.xml.xpath.XPathExpressionException;

/**
 *
 * @author ajayapra
 */
public class CallbackMessageHandlerTest {

    public static void main(String[] args) throws XPathExpressionException {
        String patternDefURI = "/Mypatterns/pattern1";
        String patternInstanceName = "hello123";
        Object correlationId = "test-abcd-xyz";
        boolean success = true;

        String s = "<pattern-result>\n";

        s = s + "<pattern-uri><![CDATA[" + patternDefURI + "]]></pattern-uri>\n";

        s = s + "<pattern-instance-name><![CDATA[" + patternInstanceName + "]]></pattern-instance-name>\n";

        s = s + "<correlation-id><![CDATA[" + correlationId + "]]></correlation-id>\n";

        s = s + "<success><![CDATA[" + success + "]]></success>\n";

        long[] eventIds = {1, 2, 3, 4, 5};
        String[] eventExtIds = {"a", "b", "c", "d", "e"};

        s = s + "<events>\n";

        for (int i = 0; i < eventIds.length; i = i + 1) {
            s = s
                    + "<event>\n"
                    + "<id>" + eventIds[i] + "</id>\n"
                    + "<ext-id>" + eventExtIds[i] + "</ext-id>\n"
                    + "</event>\n";
        }

        s = s + "</events>\n";

        s = s + "</pattern-result>";

        PatternResult patternResult = new DefaultCallbackMessageHandler().onMessage(s.getBytes());
    }
}
