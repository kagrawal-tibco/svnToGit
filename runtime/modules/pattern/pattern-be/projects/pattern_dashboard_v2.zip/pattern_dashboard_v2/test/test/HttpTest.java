/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;

/**
 *
 * @author ajayapra
 */
public class HttpTest {

    public static void main(String[] args) throws Exception {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://localhost:9090/Channels/HTTPChannel/Control");

        httppost.addHeader(new BasicHeader("_nm_", "ControRequestEvent"));
        httppost.addHeader(new BasicHeader("_ns_", "www.tibco.com/be/ontology/Events/ControRequestEvent"));
        httppost.addHeader(new BasicHeader("action", "start epl service"));
        httppost.addHeader(new BasicHeader("data", "hello123"));

        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        String responseBody = httpclient.execute(httppost, responseHandler);
        System.out.println(responseBody);

        System.out.println("----------------------------------------");

        httpclient.getConnectionManager().shutdown();
    }
}
