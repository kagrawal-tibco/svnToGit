/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import javax.xml.xpath.XPathExpressionException;

/**
 *
 * @author ajayapra
 */
public class XpathTest {

    public static void main(String[] args) throws XPathExpressionException {
        String s = XPathHelper.query("<response><success>Works</success></response>", "local-name(/response/*)");
        System.out.println("--> " + s);

        s = XPathHelper.getIfSuccess("<response><success>Works</success></response>");
        System.out.println("--> " + s);

        s = "<response><error>"
        + "<msg><![CDATA[@#$@#$SDFSDFSDGGSDFG#$%#E%]]></msg>"
        + "<trace><![CDATA[12312312313123]]></trace>"
        + "</error></response>";
        String[] arr = XPathHelper.getIfError(s);
        System.out.println("--> " + arr[0] + ", " + arr[1]);

        s = XPathHelper.getIfSuccess("<response><success><pattern-uri>/a/b</pattern-uri></success></response>");
        System.out.println("--> " + s);

        s = XPathHelper.query("<response><success><pattern-uri>/a/b</pattern-uri></success></response>", "//pattern-uri");
        System.out.println("--> " + s);
    }
}
