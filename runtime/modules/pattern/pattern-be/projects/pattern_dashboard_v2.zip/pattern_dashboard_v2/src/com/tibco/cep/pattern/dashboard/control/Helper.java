/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control;

import com.tibco.cep.pattern.dashboard.Application;
import java.lang.reflect.InvocationTargetException;
import java.util.ResourceBundle;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author ajayapra
 */
public class Helper {

    public static void $sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ex) {
        }
    }

    /**
     *
     * @param message Send null to reset to original title.
     * @throws InterruptedException
     * @throws InvocationTargetException
     */
    public static void $appendToAppTitle(final String message) throws InterruptedException, InvocationTargetException {
        SwingUtilities.invokeAndWait(new Runnable() {

            public void run() {
                ResourceBundle bundle = Application.getInstance().getResourceBundle();
                String title = bundle.getString("Application.title");

                if (message != null) {
                    title = title + " <" + message + ">";
                }

                JFrame frame = Application.getMainFrame();
                frame.setTitle(title);
            }
        });
    }

    public static long $getEventSentPauseMillis() {
    	ResourceBundle bundle = Application.getInstance().getResourceBundle();

        return Long.parseLong(bundle.getString("Application.eventSendPauseMillis"));
    }
}
