/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.RequestSender;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public class CallSimulatorRequestSender implements RequestSender {

    protected CallSimulatorRequest request;
    protected EndPoint endPoint;
    protected long intervalMillis;

    public CallSimulatorRequestSender(CallSimulatorRequest request, EndPoint endPoint, long intervalMillis) {
        this.request = request;
        this.endPoint = endPoint;
        this.intervalMillis = intervalMillis;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public CallSimulatorRequest getRequest() {
        return request;
    }

    public Iterator<Object> prepareSender() {
        return new Sender();
    }

    protected class Sender implements Iterator<Object> {

        protected LinkedHashMap<String, Object> work;
        protected Iterator<Entry<String, Object>> workIterator;

        public Sender() {
            this.work = new LinkedHashMap<String, Object>();

            String phNum = request.getPhNum();

            work.put("Processing call sequence for [" + phNum + "]", null);

            //------------

            CallRequestEventFactory callRequestEventFactory = new CallRequestEventFactory();
            List<AbstractCallRequestEvent> listOfREs = callRequestEventFactory.create(request);

            for (AbstractCallRequestEvent abstractCallRequestEvent : listOfREs) {
                work.put("Sending [" + abstractCallRequestEvent.getClass().getSimpleName()
                        + "] with extId [" + abstractCallRequestEvent.getExtId() + "]", null);

                work.put("Sent [" + abstractCallRequestEvent.getClass().getSimpleName()
                        + "] with extId [" + abstractCallRequestEvent.getExtId() + "]", abstractCallRequestEvent);

                work.put("Paused for [" + intervalMillis + "] milliseconds after "
                        + abstractCallRequestEvent.getExtId(), intervalMillis);
            }

            //------------

            work.put("Processed call sequence for [" + phNum + "]", null);

            //------------

            workIterator = work.entrySet().iterator();
        }

        public boolean hasNext() {
            return workIterator.hasNext();
        }

        public Object next() {
            Entry<String, Object> entry = workIterator.next();

            Object value = entry.getValue();
            if (value != null) {
                if (value instanceof Long) {
                    try {
                        Thread.sleep(intervalMillis);
                    } catch (InterruptedException ex) {
                    }
                } else {
                    AbstractCallRequestEvent acre = (AbstractCallRequestEvent) value;

                    try {
                        String response = endPoint.sendAndReceive(acre);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(entry.getKey(), err[0], acre, e);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();

                        return new ExternalErrorEvent(entry.getKey(), ex.getMessage(), acre, ex);
                    }
                }
            }

            return entry.getKey();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
