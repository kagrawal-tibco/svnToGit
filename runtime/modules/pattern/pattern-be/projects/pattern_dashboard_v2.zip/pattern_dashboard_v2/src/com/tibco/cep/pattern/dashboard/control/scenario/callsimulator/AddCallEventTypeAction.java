/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.callsimulator;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;

/**
 *
 * @author ajayapra
 */
public class AddCallEventTypeAction extends AbstractAction {

    protected JComboBox sourceCombo;
    protected JList targetList;

    public AddCallEventTypeAction(JComboBox sourceCombo, JList targetList) {
        this.sourceCombo = sourceCombo;
        this.targetList = targetList;
    }

    public void actionPerformed(ActionEvent e) {
        DefaultListModel listModel = (DefaultListModel) targetList.getModel();

        Object selectedItem = sourceCombo.getSelectedItem();
        CallEventType callEventType = (CallEventType) selectedItem;
        listModel.addElement(callEventType);

        int i = listModel.getSize() - 1;
        targetList.ensureIndexIsVisible(i);
    }
}
