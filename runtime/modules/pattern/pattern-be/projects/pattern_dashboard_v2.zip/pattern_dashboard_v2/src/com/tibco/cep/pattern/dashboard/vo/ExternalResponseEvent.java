/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

/**
 *
 * @author ajayapra
 */
public class ExternalResponseEvent {

    protected String comment;
    protected Object response;
    protected ExternalRequestEvent requestMessage;

    public ExternalResponseEvent(String comment, Object response) {
        this.comment = comment;
        this.response = response;
    }

    public ExternalResponseEvent(String comment, Object response, ExternalRequestEvent requestMessage) {
        this.comment = comment;
        this.response = response;
        this.requestMessage = requestMessage;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public ExternalRequestEvent getRequestMessage() {
        return requestMessage;
    }

    public void setRequestMessage(ExternalRequestEvent requestMessage) {
        this.requestMessage = requestMessage;
    }

    public Object getResponse() {
        return response;
    }

    public void setResponse(Object response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " Comment [" + comment + "], Response [" + response + "]";
    }
}
