/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

/**
 *
 * @author ajayapra
 */
public class CallPlacedRequestEvent extends AbstractCallRequestEvent {

    public CallPlacedRequestEvent(String extId, String phNumber) {
        super(extId, phNumber);
    }

    @Override
    protected String getNM() {
        return "CallPlaced";
    }
}
