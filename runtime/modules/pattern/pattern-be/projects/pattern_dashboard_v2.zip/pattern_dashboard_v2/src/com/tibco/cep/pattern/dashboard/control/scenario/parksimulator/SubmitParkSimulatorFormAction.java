/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.parksimulator;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import com.tibco.cep.pattern.dashboard.vo.parksimulator.ParkSimulatorRequest;
import com.tibco.cep.pattern.dashboard.vo.parksimulator.ParkSimulatorRequestSender;
import java.awt.event.ActionEvent;
import java.util.Iterator;
import javax.swing.AbstractAction;
import javax.swing.JCheckBox;
import javax.swing.JTextField;

/**
 *
 * @author ajayapra
 */
public class SubmitParkSimulatorFormAction extends AbstractAction {

    protected JCheckBox[] papa;
    protected JCheckBox[] mama;
    protected JCheckBox[] baby;
    protected JCheckBox[] grandma;
    protected JCheckBox[] wolf;
    protected JCheckBox[] hood;
    protected JCheckBox[] goldilocks;
    protected JCheckBox close;
    protected JTextField parkAreaIdTextField;

    /**
     *
     * @param papa Enter at [0] and Leave at [1].
     * @param mama Enter at [0] and Leave at [1].
     * @param baby Enter at [0] and Leave at [1].
     * @param grandma Enter at [0] and Leave at [1].
     * @param wolf Enter at [0] and Leave at [1].
     * @param hood Enter at [0] and Leave at [1].
     * @param goldilocks Enter at [0] and Leave at [1].
     * @param close
     * @param parkAreaIdTextField
     */
    public SubmitParkSimulatorFormAction(JCheckBox[] papa, JCheckBox[] mama, JCheckBox[] baby,
            JCheckBox[] grandma, JCheckBox[] wolf, JCheckBox[] hood, JCheckBox[] goldilocks,
            JCheckBox close, JTextField parkAreaIdTextField) {
        this.papa = papa;
        this.mama = mama;
        this.baby = baby;
        this.grandma = grandma;
        this.wolf = wolf;
        this.hood = hood;
        this.goldilocks = goldilocks;
        this.close = close;
        this.parkAreaIdTextField = parkAreaIdTextField;
    }

    protected boolean check(JCheckBox enter, JCheckBox leave, ParkSimulatorRequest request) {
        if (leave.isSelected() && enter.isSelected() == false) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            enter.requestFocusInWindow();

            statusLabelService.writeMessage("Warning: " + enter.getText() + " cannot leave without entering the park area");
        }

        String name = enter.getText();
        ParkItemType item = ParkItemType.getItem(name);

        if (enter.isSelected()) {
            request.addEnter(item);
        }

        if (leave.isSelected()) {
            request.addLeave(item);
        }

        return true;
    }

    public void actionPerformed(ActionEvent e) {
        String area = parkAreaIdTextField.getText();
        if (area == null || area.trim().length() == 0) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            parkAreaIdTextField.setText(null);

            parkAreaIdTextField.requestFocusInWindow();

            statusLabelService.writeMessage("Please provide a park area");

            return;
        }

        ParkSimulatorRequest request = new ParkSimulatorRequest();

        request.setParkAreaId(area);

        //--------------

        boolean valid = check(papa[0], papa[1], request);
        if (valid == false) {
            return;
        }

        valid = check(mama[0], mama[1], request);
        if (valid == false) {
            return;
        }

        valid = check(baby[0], baby[1], request);
        if (valid == false) {
            return;
        }

        valid = check(grandma[0], grandma[1], request);
        if (valid == false) {
            return;
        }

        valid = check(wolf[0], wolf[1], request);
        if (valid == false) {
            return;
        }

        valid = check(hood[0], hood[1], request);
        if (valid == false) {
            return;
        }

        valid = check(goldilocks[0], goldilocks[1], request);
        if (valid == false) {
            return;
        }

        //--------------

        if (close.isSelected()) {
            request.setClose(true);
        }

        //--------------

        if (request.getEnterSet().isEmpty() && request.getLeaveSet().isEmpty() && request.isClose() == false) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            statusLabelService.writeMessage("Park cannot be simulated correctly when there is no one inside");

            return;
        }

        //--------------

        AsyncJob asyncJob = new AsyncJob(request);

        AsyncExecutor asyncExecutor = Registry.getRegistry().getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected static class AsyncJob implements Runnable {

        protected ParkSimulatorRequest request;
        protected AnimatedJob animatedJob;

        public AsyncJob(ParkSimulatorRequest request) {
            this.request = request;
            this.animatedJob = new AnimatedJob("Preparing");
        }

        public void run() {
            animatedJob.start();

            Registry registry = Registry.getRegistry();
            EndPoint endPoint = registry.getVoRoot().getEndPoint();
            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before submitting");

                    Helper.$sleep(1200);
                } else {
                    long pauseMillis = Helper.$getEventSentPauseMillis();

                    ParkSimulatorRequestSender requestSender = new ParkSimulatorRequestSender(request, endPoint, pauseMillis);

                    Iterator<Object> iterator = requestSender.prepareSender();

                    for (; iterator.hasNext();) {
                        Object message = iterator.next();

                        if (message instanceof ExternalErrorEvent) {
                            ExternalErrorEvent responseMessage = (ExternalErrorEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());

                            throw responseMessage.getException();
                        } else if (message instanceof ExternalResponseEvent) {
                            ExternalResponseEvent responseMessage = (ExternalResponseEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());
                        } else {
                            animatedJob.updateProgress(message.toString());
                        }

                        Helper.$sleep(300);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
