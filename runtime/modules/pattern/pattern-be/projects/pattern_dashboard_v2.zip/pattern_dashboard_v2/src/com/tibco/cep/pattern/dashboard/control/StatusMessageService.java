/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control;

import com.tibco.cep.pattern.dashboard.util.CallFromUiThread;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author ajayapra
 */
public class StatusMessageService {

    protected JTextField statusTextField;

    public StatusMessageService() {
    }

    public JTextField getStatusTextField() {
        return statusTextField;
    }

    public void setStatusTextField(JTextField statusTextField) {
        this.statusTextField = statusTextField;
    }

    @CallFromUiThread
    public void writeMessage(final String message) {
        System.out.println("Status message: " + message);

        statusTextField.setText(message);
    }

    public void sendMessage(final String message) {
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                System.out.println("Status message: " + message);

                statusTextField.setText(message);
            }
        });
    }

    public void sendMessageAndWait(final String message)
            throws InterruptedException, InvocationTargetException {
        SwingUtilities.invokeAndWait(new Runnable() {

            public void run() {
                System.out.println("Status message: " + message);

                statusTextField.setText(message);
            }
        });
    }
}
