/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.parksimulator;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JCheckBox;
import javax.swing.JTextField;

/**
 *
 * @author ajayapra
 */
public class ClearParkSimulatorFormAction extends AbstractAction {

    protected JCheckBox[] checkBoxes;
    protected JTextField parkAreaIdTextField;

    public ClearParkSimulatorFormAction(JCheckBox[] checkBoxes, JTextField parkAreaIdTextField) {
        this.checkBoxes = checkBoxes;
        this.parkAreaIdTextField = parkAreaIdTextField;
    }

    public void actionPerformed(ActionEvent e) {
        for (JCheckBox checkBox : checkBoxes) {
            checkBox.setSelected(false);
        }

        parkAreaIdTextField.setText(null);
    }
}
