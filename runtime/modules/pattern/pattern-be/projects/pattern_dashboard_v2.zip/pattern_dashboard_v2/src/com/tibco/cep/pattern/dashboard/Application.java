package com.tibco.cep.pattern.dashboard;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ResourceBundle;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.ui.PatterndashboardView;

public class Application {
	
	private static final Application INSTANCE = new Application();
	private static PatterndashboardView mainFrame;
	
	private Application() {		
	}
	
	public static Application getInstance() {
		return INSTANCE;
	}
	
	public ResourceBundle getResourceBundle() {
		return getResourceBundle((String)null);
	}
	
	public ResourceBundle getResourceBundle(String name) {
		if(name == null) {
			return ResourceBundle.getBundle(Application.class.getName());
		}
		return ResourceBundle.getBundle(name);
	}
	
	public ResourceBundle getResourceBundle(Class<?> klass) {
		return getResourceBundle(klass.getName());
	}
	
	public void show(final JDialog dialog) {
		Thread dialogRunner = new Thread(new Runnable(){
            @Override
            public void run() {
                try {
                    SwingUtilities.invokeAndWait(new Runnable() {
                        @Override
                        public void run() {
                            dialog.pack();
                            dialog.validate();
                            dialog.setVisible(true);
                        }
                    });
                } catch (Exception ex) {
                	ex.printStackTrace();
                }
            }
        });
		dialogRunner.start();
	}
	
	public static void main(String[] args) {
		ResourceBundle bundle = Application.getInstance().getResourceBundle();
		initLAF(bundle);		
		Registry.getRegistry().start();
		mainFrame = new PatterndashboardView();
		mainFrame.addWindowListener(new WindowListener(){

			@Override
			public void windowActivated(WindowEvent arg0) {
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				System.exit(0);
			}

			@Override
			public void windowClosing(WindowEvent arg0) {				
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
			}

			@Override
			public void windowOpened(WindowEvent arg0) {
			}

		});
		mainFrame.setTitle(bundle.getString("Application.title"));
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SwingUtilities.invokeLater(new Runnable(){

			@Override
			public void run() {
				mainFrame.pack();
				mainFrame.setVisible(true);
			}});
	}
	
	public static PatterndashboardView getMainFrame() {
		return mainFrame;
	}

	private static void initLAF(ResourceBundle bundle) {
		String lafClass = bundle.getString("Application.lookAndFeel");
		if(lafClass != null) {
			try {
				UIManager.setLookAndFeel(lafClass);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
	}

}
