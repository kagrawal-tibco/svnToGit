/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

/**
 *
 * @author ajayapra
 */
public class ParkClosedRequestEvent extends AbstractParkRequestEvent {

    public ParkClosedRequestEvent(String extId, String areaId) {
        super(extId, areaId);
    }

    @Override
    protected String getNM() {
        return "ParkClosed";
    }
}
