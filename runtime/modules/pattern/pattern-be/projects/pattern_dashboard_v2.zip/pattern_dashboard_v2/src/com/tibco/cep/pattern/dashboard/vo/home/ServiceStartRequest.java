/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.home;

import com.tibco.cep.pattern.dashboard.vo.Request;

/**
 *
 * @author ajayapra
 */
public class ServiceStartRequest implements Request {
}
