/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public abstract class ExternalRequestEvent {

    protected String targetPath;
    protected HashMap<String, Object> headers;
    protected HashMap<String, Object> parameters;

    public ExternalRequestEvent() {
        this.headers = new HashMap<String, Object>();
        this.parameters = new HashMap<String, Object>();
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public HashMap<String, Object> getHeaders() {
        return headers;
    }

    public void addHeader(String key, Object value) {
        headers.put(key, value);
    }

    public void setHeaders(HashMap<String, Object> headers) {
        this.headers = headers;
    }

    public HashMap<String, Object> getParameters() {
        return parameters;
    }

    public void addParameter(String key, Object value) {
        parameters.put(key, value);
    }

    public void setParameters(HashMap<String, Object> parameters) {
        this.parameters = parameters;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append(getClass().getSimpleName());
        builder.append("\n");

        builder.append(targetPath);
        builder.append("\n");

        for (Entry<String, Object> entry : headers.entrySet()) {
            builder.append("Header [");
            builder.append(entry.getKey());
            builder.append(": ");
            builder.append(entry.getValue());
            builder.append("]\n");
        }

        for (Entry<String, Object> entry : parameters.entrySet()) {
            builder.append("Parameter [");
            builder.append(entry.getKey());
            builder.append(": ");
            builder.append(entry.getValue());
            builder.append("]\n");
        }

        return builder.toString();
    }
}
