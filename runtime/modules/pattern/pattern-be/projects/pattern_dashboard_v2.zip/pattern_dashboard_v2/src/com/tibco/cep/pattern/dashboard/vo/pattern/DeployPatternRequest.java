/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.pattern;

import com.tibco.cep.pattern.dashboard.vo.Request;

/**
 *
 * @author ajayapra
 */
public class DeployPatternRequest implements Request {

    protected String pattern;
    protected String nickName;

    public DeployPatternRequest() {
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}
