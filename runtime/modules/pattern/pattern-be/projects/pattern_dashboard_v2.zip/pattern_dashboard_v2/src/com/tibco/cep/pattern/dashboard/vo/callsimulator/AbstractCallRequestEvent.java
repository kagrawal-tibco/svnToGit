/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

import com.tibco.cep.pattern.dashboard.vo.*;

/**
 *
 * @author ajayapra
 */
public abstract class AbstractCallRequestEvent extends AbstractExternalRequestEvent {

    public static final String PATH = "/Channels/HTTPChannel/Data";
    public static final String HEADER_NS_PREFIX = "www.tibco.com/be/ontology/Events/CallSim/";
    public static final String FIELD_PH_NUM = "phNumber";

    /**
     * @see #getNM() 
     * @param phNumber
     */
    public AbstractCallRequestEvent(String extId, String phNumber) {
        super(PATH, extId);

        addParameter(FIELD_PH_NUM, phNumber);
    }

    /**
     * Override this.
     * @return
     */
    protected String getNM() {
        return "BaseDataEvent";
    }

    protected final String getNS() {
        return HEADER_NS_PREFIX + getNM();
    }

    public void setPhNumber(String value) {
        addParameter(FIELD_PH_NUM, value);
    }
}
