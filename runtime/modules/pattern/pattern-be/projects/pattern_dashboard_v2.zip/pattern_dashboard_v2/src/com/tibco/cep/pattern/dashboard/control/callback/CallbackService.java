/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.callback;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import com.tibco.cep.pattern.dashboard.Application;

/**
 *
 * @author ajayapra
 */
public class CallbackService {
    protected ElementalHttpServer httpServer;
    protected DefaultCallbackMessageHandler messageHandler;

    public CallbackService() {
    }

    public void start() {
        int port = getHTTPCallbackPort();
        try {
            messageHandler = new DefaultCallbackMessageHandler();
            httpServer = new ElementalHttpServer();
            httpServer.start(port, messageHandler);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public void stop() {
        try {
            httpServer.stop();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    public String makeClosureCSV(String patternUri) {
        String closureCSV = "patternUri=" + patternUri;

        String[] callback = getHTTPCallbackUrl();

        closureCSV = closureCSV + ",callbackHost=" + callback[0];
        closureCSV = closureCSV + ",callbackPort=" + callback[1];
        closureCSV = closureCSV + ",callbackUri=" + callback[2];

        return closureCSV;
    }

    public int getHTTPCallbackPort() {
        ResourceBundle bundle = Application.getInstance().getResourceBundle();
        String httpPort = bundle.getString("Application.localHttpPort");
        return Integer.parseInt(httpPort);
    }

    /**
     *
     * @return [0]=host, [1]=post, [2]=callbackUri
     */
    public String[] getHTTPCallbackUrl() {
        ResourceBundle bundle = Application.getInstance().getResourceBundle();
        String callbackUri = bundle.getString("Application.localHttpCallbackUri");
        int httpPort = getHTTPCallbackPort();
        String localAddress = "localhost";
        try {
            localAddress = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        }

        return new String[]{localAddress, httpPort + "", callbackUri};
    }
}
