/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.callsimulator;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 *
 * @author ajayapra
 */
public class ClearCallSimualtorFormAction extends AbstractAction {

    protected JTextField phNumTextField;
    protected JComboBox sequenceChooser;
    protected JList sequenceList;

    public ClearCallSimualtorFormAction(JTextField phNumTextField, JComboBox sequenceChooser, JList sequenceList) {
        this.phNumTextField = phNumTextField;
        this.sequenceChooser = sequenceChooser;
        this.sequenceList = sequenceList;
    }

    public void actionPerformed(ActionEvent e) {
        phNumTextField.setText(null);

        sequenceChooser.setSelectedIndex(0);

        DefaultListModel defaultListModel = (DefaultListModel) sequenceList.getModel();
        defaultListModel.clear();
    }
}
