package com.tibco.cep.pattern.dashboard.util;

/*
* Author: Ashwin Jayaprakash / Date: 12/15/10 / Time: 2:16 PM
*/
public interface UiConstants {
    String DEFAULT_ENCODING = "UTF-8";
    String DEFAULT_CONTENT_TYPE = "text/bql; charset=" + DEFAULT_ENCODING;
}
