/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.transport;

import com.tibco.cep.pattern.dashboard.vo.ExternalRequestEvent;

/**
 *
 * @author ajayapra
 */
public abstract class EndPoint {

    protected String url;

    public EndPoint() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public abstract String connect() throws Exception;

    public abstract String ping() throws Exception;

    public abstract String sendAndReceive(ExternalRequestEvent message) throws Exception;

    public abstract String disconnect() throws Exception;
}
