package com.tibco.cep.pattern.dashboard.control.home;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.SwingUtilities;

import com.tibco.cep.pattern.dashboard.ui.PatterndashboardView;

public class ExitDashboardAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	private final PatterndashboardView view;
	public ExitDashboardAction(PatterndashboardView view) {    		
		this.view = view;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		SwingUtilities.invokeLater(new Runnable(){

			@Override
			public void run() {
				view.dispose();
			}});					
	}

}
