/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.model.result;

import com.tibco.cep.pattern.dashboard.vo.callback.PatternResult;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ajayapra
 */
public class ResultTableModel extends DefaultTableModel {

    public static enum Column {

        ROW_NUM("#"),
        PATTERN_URI("URI"),
        PATTERN_INSTANCE_NAME("Name"),
        CORRELATION_ID("Correlation Id"),
        SUCCESS("Success"),
        EVENT_COUNT("Events");
        protected String name;

        private Column(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        @Override
        public String toString() {
            return getName();
        }
    }
    protected final AtomicInteger rowNum;
    protected final Object lock;

    public ResultTableModel() {
        super(Column.values(), 0);

        this.rowNum = new AtomicInteger();
        this.lock = new Object();
    }

    public void addPatternResult(PatternResult patternResult) {
        List<PatternResult.EventInfo> eventInfos = patternResult.getEventInfos();

        Collections.reverse(eventInfos);

        synchronized (lock) {
            for (PatternResult.EventInfo eventInfo : eventInfos) {
                String[] row = {
                    rowNum.incrementAndGet() + "",
                    "",
                    "",
                    "",
                    "",
                    eventInfo.getExtId()};

                insertRow(0, row);
            }

            //------------

            String[] row = {
                rowNum.incrementAndGet() + "",
                patternResult.getPatternUri(),
                patternResult.getPatternInstanceName(),
                patternResult.getCorrelationId(),
                patternResult.getSuccess(),
                "(" + eventInfos.size() + ")"};

            insertRow(0, row);
        }
    }
}
