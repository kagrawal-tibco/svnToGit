package com.tibco.cep.pattern.dashboard.vo;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployedPattern;
import java.util.Collection;
import java.util.HashMap;

/*
 * Author: Ashwin Jayaprakash / Date: Jan 29, 2010 / Time: 1:22:34 PM
 */
public class VoRoot {

    protected EndPoint endPoint;
    protected boolean started;
    protected HashMap<String, DeployedPattern> deployedPatterns;

    public VoRoot() {
        this.deployedPatterns = new HashMap<String, DeployedPattern>();
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(EndPoint endPoint) {
        this.endPoint = endPoint;
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean started) {
        this.started = started;
    }

    public Collection<DeployedPattern> getDeployedPatterns() {
        return deployedPatterns.values();
    }

    public DeployedPattern getDeployedPattern(String key) {
        return deployedPatterns.get(key);
    }

    public void addDeployedPattern(DeployedPattern deployedPattern) {
        deployedPatterns.put(deployedPattern.getKey(), deployedPattern);
    }

    public void removeDeployedPattern(String key) {
        deployedPatterns.remove(key);
    }
}
