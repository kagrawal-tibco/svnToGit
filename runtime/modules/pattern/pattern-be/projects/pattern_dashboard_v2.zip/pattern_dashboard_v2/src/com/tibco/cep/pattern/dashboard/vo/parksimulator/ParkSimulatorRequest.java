/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

import com.tibco.cep.pattern.dashboard.control.scenario.parksimulator.ParkItemType;
import com.tibco.cep.pattern.dashboard.vo.Request;
import java.util.EnumMap;

/**
 *
 * @author ajayapra
 */
public class ParkSimulatorRequest implements Request {

    protected String parkAreaId;
    protected EnumMap<ParkItemType, Object> enterSet;
    protected EnumMap<ParkItemType, Object> leaveSet;
    protected boolean close;

    public ParkSimulatorRequest() {
        this.enterSet = new EnumMap<ParkItemType, Object>(ParkItemType.class);
        this.leaveSet = new EnumMap<ParkItemType, Object>(ParkItemType.class);
    }

    public boolean isClose() {
        return close;
    }

    public void setClose(boolean close) {
        this.close = close;
    }

    public EnumMap<ParkItemType, Object> getEnterSet() {
        return enterSet;
    }

    public void addEnter(ParkItemType item) {
        enterSet.put(item, null);
    }

    public EnumMap<ParkItemType, Object> getLeaveSet() {
        return leaveSet;
    }

    public void addLeave(ParkItemType item) {
        leaveSet.put(item, null);
    }

    public String getParkAreaId() {
        return parkAreaId;
    }

    public void setParkAreaId(String parkAreaId) {
        this.parkAreaId = parkAreaId;
    }
}
