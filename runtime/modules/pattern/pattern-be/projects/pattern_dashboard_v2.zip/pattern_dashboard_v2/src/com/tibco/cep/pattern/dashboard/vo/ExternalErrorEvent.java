/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

/**
 *
 * @author ajayapra
 */
public class ExternalErrorEvent extends ExternalResponseEvent {

    protected Exception exception;

    public ExternalErrorEvent(String comment, Object response, ExternalRequestEvent requestMessage, Exception exception) {
        super(comment, response, requestMessage);

        this.exception = exception;
    }

    public ExternalErrorEvent(String comment, Object response, Exception exception) {
        super(comment, response);

        this.exception = exception;
    }

    public Exception getException() {
        return exception;
    }

    public void setException(Exception exception) {
        this.exception = exception;
    }
}
