/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.scenario.parksimulator.ParkItemType;
import com.tibco.cep.pattern.dashboard.util.UUIDService;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ajayapra
 */
public class ParkRequestEventFactory {

    public List<AbstractParkRequestEvent> create(ParkSimulatorRequest request) {
        UUIDService uuidService = Registry.getRegistry().getUuidService();

        String areaId = request.getParkAreaId();
        LinkedList<AbstractParkRequestEvent> list = new LinkedList<AbstractParkRequestEvent>();

        for (ParkItemType parkItemType : request.getEnterSet().keySet()) {
            String parkItemName = parkItemType.name().toLowerCase();
            String itemId = areaId + "-" + parkItemName;
            String extId = uuidService.nextUUID("parksim-enter-" + itemId);

            switch (parkItemType) {
                case PAPA:
                case MAMA:
                case BABY:
                case GRANDMA:
                case WOLF:
                case HOOD:
                case GOLDILOCKS: {
                    list.add(new ParkItemEnteredRequestEvent(extId, areaId, parkItemType.getName(), itemId));
                    break;
                }
                case CLOSE:
                default: {
                    throw new IllegalArgumentException(parkItemType.getName() + " is invalid for an 'entry' type");
                }
            }
        }

        for (ParkItemType parkItemType : request.getLeaveSet().keySet()) {
            String parkItemName = parkItemType.name().toLowerCase();
            String itemId = areaId + "-" + parkItemName;
            String extId = uuidService.nextUUID("parksim-leave-" + itemId);

            switch (parkItemType) {
                case PAPA:
                case MAMA:
                case BABY:
                case GRANDMA:
                case WOLF:
                case HOOD:
                case GOLDILOCKS: {
                    list.add(new ParkItemLeftRequestEvent(extId, areaId, parkItemType.getName(), itemId));
                    break;
                }
                case CLOSE:
                default: {
                    throw new IllegalArgumentException(parkItemType.getName() + " is invalid for a 'leave' type");
                }
            }
        }

        if (request.isClose()) {
            String extId = uuidService.nextUUID("parksim-close-" + areaId);

            list.add(new ParkClosedRequestEvent(extId, areaId));
        }

        return list;
    }
}
