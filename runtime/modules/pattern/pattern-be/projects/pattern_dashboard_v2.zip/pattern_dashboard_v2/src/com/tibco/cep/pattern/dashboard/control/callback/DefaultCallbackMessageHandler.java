/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.callback;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.vo.callback.PatternResult;
import java.io.StringReader;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *
 * @author ajayapra
 */
public class DefaultCallbackMessageHandler implements CallbackMessageHandler {

    public static final String XML_NODE_ROOT = "pattern-result";
    public static final String XML_NODE_PATTERN_URI = "pattern-uri";
    public static final String XML_NODE_PATTERN_INSTANCE_NAME = "pattern-instance-name";
    public static final String XML_NODE_CORRELATION_ID = "correlation-id";
    public static final String XML_NODE_SUCCESS = "success";
    public static final String XML_NODE_EVENTS = "events";
    public static final String XML_NODE_EVENT = "event";
    public static final String XML_NODE_EVENT_ID = "id";
    public static final String XML_NODE_EVENT_EXT_ID = "ext-id";
    protected XPathExpression xpathRoot;
    protected XPathExpression xpathPatternURI;
    protected XPathExpression xpathPatternInstanceName;
    protected XPathExpression xpathCorrelationId;
    protected XPathExpression xpathSuccess;
    protected XPathExpression xpathEventIds;
    protected XPathExpression xpathEventExtIds;

    public DefaultCallbackMessageHandler() throws XPathExpressionException {
        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();

        this.xpathRoot = xpath.compile("/");

        this.xpathPatternURI = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_PATTERN_URI + "/text()");
        this.xpathPatternInstanceName = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_PATTERN_INSTANCE_NAME + "/text()");
        this.xpathCorrelationId = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_CORRELATION_ID + "/text()");
        this.xpathSuccess = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_SUCCESS + "/text()");

        this.xpathEventIds = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_EVENTS
                + "/" + XML_NODE_EVENT + "/" + XML_NODE_EVENT_ID + "/text()");

        this.xpathEventExtIds = xpath.compile("/" + XML_NODE_ROOT + "/" + XML_NODE_EVENTS
                + "/" + XML_NODE_EVENT + "/" + XML_NODE_EVENT_EXT_ID + "/text()");
    }

    @Override
    public PatternResult onMessage(byte[] bytes) {
        String string = new String(bytes);

        try {
            InputSource inputSource = new InputSource(new StringReader(string));
            Node rootNode = (Node) xpathRoot.evaluate(inputSource, XPathConstants.NODE);

            PatternResult patternResult = new PatternResult();

            String s = xpathPatternURI.evaluate(rootNode);
            patternResult.setPatternUri(s);

            s = xpathPatternInstanceName.evaluate(rootNode);
            patternResult.setPatternInstanceName(s);

            s = xpathCorrelationId.evaluate(rootNode);
            patternResult.setCorrelationId(s);

            s = xpathSuccess.evaluate(rootNode);
            patternResult.setSuccess(s);

            NodeList eventIdNodeList = (NodeList) xpathEventIds.evaluate(rootNode, XPathConstants.NODESET);
            NodeList eventExtIdNodeList = (NodeList) xpathEventExtIds.evaluate(rootNode, XPathConstants.NODESET);

            int count = eventIdNodeList.getLength();
            if (count != eventExtIdNodeList.getLength()) {
                throw new Exception("Numbers of Event Ids [" + count
                        + "] and ExtIds [" + eventExtIdNodeList.getLength() + "] do not match");
            }

            for (int i = 0; i < count; i++) {
                Node idNode = eventIdNodeList.item(i);
                String id = idNode.getTextContent();

                Node extIdNode = eventExtIdNodeList.item(i);
                String extId = extIdNode.getTextContent();

                PatternResult.EventInfo eventInfo = new PatternResult.EventInfo();
                eventInfo.setId(id);
                eventInfo.setExtId(extId);

                patternResult.addEventInfos(eventInfo);
            }

            Registry.getRegistry().getModelRoot().getResultTableModel().addPatternResult(patternResult);

            return patternResult;
        } catch (Exception e) {
            System.err.println("Error occurred while processing callback message:\n" + string);

            e.printStackTrace();
        }

        return null;
    }
}
