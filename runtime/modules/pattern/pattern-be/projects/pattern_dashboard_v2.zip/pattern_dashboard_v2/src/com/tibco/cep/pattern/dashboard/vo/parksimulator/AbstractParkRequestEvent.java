/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

import com.tibco.cep.pattern.dashboard.vo.*;

/**
 *
 * @author ajayapra
 */
public abstract class AbstractParkRequestEvent extends AbstractExternalRequestEvent {

    public static final String PATH = "/Channels/HTTPChannel/Data";
    public static final String HEADER_NS_PREFIX = "www.tibco.com/be/ontology/Events/ParkSim/";
    public static final String FIELD_AREA_ID = "areaId";

    /**
     * @see #getNM() 
     * @param areaId
     */
    public AbstractParkRequestEvent(String extId, String areaId) {
        super(PATH, extId);

        addParameter(FIELD_AREA_ID, areaId);
    }

    /**
     * Override this.
     * @return
     */
    protected String getNM() {
        return "BaseDataEvent";
    }

    protected final String getNS() {
        return HEADER_NS_PREFIX + getNM();
    }

    public void setAreaId(String value) {
        addParameter(FIELD_AREA_ID, value);
    }
}
