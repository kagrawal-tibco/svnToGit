/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.transport;

import com.tibco.cep.pattern.dashboard.control.transport.http.HttpEndPoint;

/**
 *
 * @author ajayapra
 */
public class EndPointCreator {

    public EndPoint create(String url) {
        HttpEndPoint httpEndPoint = new HttpEndPoint();
        httpEndPoint.setUrl(url);

        return httpEndPoint;
    }
}
