/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.model;

import com.tibco.cep.pattern.dashboard.model.result.ResultTableModel;

/**
 *
 * @author ajayapra
 */
public class ModelRoot {

    protected ResultTableModel resultTableModel;

    public ModelRoot() {
        this.resultTableModel = new ResultTableModel();
    }

    public ResultTableModel getResultTableModel() {
        return resultTableModel;
    }
}
