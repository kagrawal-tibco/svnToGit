/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.pattern;

/**
 *
 * @author ajayapra
 */
public class DeployedPattern {

    protected String key;
    protected String uri;
    protected String instanceName;
    protected DeployPatternRequest patternRequest;

    public DeployedPattern() {
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public DeployPatternRequest getPatternRequest() {
        return patternRequest;
    }

    public void setPatternRequest(DeployPatternRequest patternRequest) {
        this.patternRequest = patternRequest;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }
}
