/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

/**
 *
 * @author ajayapra
 */
public class ParkItemEnteredRequestEvent extends AbstractParkRequestEvent {

    public static final String FIELD_NAME = "name";
    public static final String FIELD_ITEM_ID = "itemId";

    public ParkItemEnteredRequestEvent(String extId, String areaId, String name, String itemId) {
        super(extId, areaId);

        addParameter(FIELD_NAME, name);
        addParameter(FIELD_ITEM_ID, itemId);
    }

    @Override
    protected String getNM() {
        return "ParkItemEntered";
    }
}
