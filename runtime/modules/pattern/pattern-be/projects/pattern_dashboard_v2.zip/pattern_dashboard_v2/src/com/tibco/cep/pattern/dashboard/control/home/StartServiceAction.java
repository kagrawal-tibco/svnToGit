/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.home;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import com.tibco.cep.pattern.dashboard.vo.VoRoot;
import com.tibco.cep.pattern.dashboard.vo.home.ServiceStartRequest;
import com.tibco.cep.pattern.dashboard.vo.home.ServiceStartRequestSender;
import java.awt.event.ActionEvent;
import java.util.Iterator;
import javax.swing.AbstractAction;

/**
 *
 * @author ajayapra
 */
public class StartServiceAction extends AbstractAction {

    public void actionPerformed(ActionEvent e) {
        Registry registry = Registry.getRegistry();
        EndPoint endPoint = registry.getVoRoot().getEndPoint();

        AsyncJob asyncJob = new AsyncJob(endPoint);

        AsyncExecutor asyncExecutor = registry.getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected static class AsyncJob implements Runnable {

        protected EndPoint endPoint;
        protected AnimatedJob animatedJob;

        public AsyncJob(EndPoint endPoint) {
            this.endPoint = endPoint;
            this.animatedJob = new AnimatedJob("Starting service");
        }

        public void run() {
            animatedJob.start();

            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before starting the service");

                    Helper.$sleep(1200);
                } else {
                    ServiceStartRequest request = new ServiceStartRequest();
                    ServiceStartRequestSender requestSender = new ServiceStartRequestSender(request, endPoint);

                    Iterator<Object> iterator = requestSender.prepareSender();

                    for (; iterator.hasNext();) {
                        Object message = iterator.next();

                        if (message instanceof ExternalErrorEvent) {
                            ExternalErrorEvent responseMessage = (ExternalErrorEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());

                            throw responseMessage.getException();
                        } else if (message instanceof ExternalResponseEvent) {
                            ExternalResponseEvent responseMessage = (ExternalResponseEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());
                        } else {
                            animatedJob.updateProgress(message.toString());
                        }

                        Helper.$sleep(300);
                    }

                    VoRoot voRoot = Registry.getRegistry().getVoRoot();
                    voRoot.setStarted(true);
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred while starting the service [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
