/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.transport.http;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ControlRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalRequestEvent;
import org.apache.http.Header;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import java.util.Map.Entry;

/**
 * @author ajayapra
 */
public class HttpEndPoint extends EndPoint {

    @Override
    public String connect() throws Exception {
        return sendAndReceive(new ControlRequestEvent(null, null));
    }

    protected String getFullPath(ExternalRequestEvent message) {
        return (message.getTargetPath() == null) ? url : (url + message.getTargetPath());
    }

    @Override
    public String ping() throws Exception {
        return sendAndReceive(new ControlRequestEvent(null, null));
    }

    @Override
    public String sendAndReceive(ExternalRequestEvent message) throws Exception {
        String path = getFullPath(message);

        HttpPost httppost = new HttpPost(path);
        for (Entry<String, Object> entry : message.getHeaders().entrySet()) {
            Object v = entry.getValue();
            String sv = (v == null) ? null : v.toString();

            httppost.addHeader(entry.getKey(), sv);
        }

        //---------------

        for (Entry<String, Object> entry : message.getParameters().entrySet()) {
            Object v = entry.getValue();
            String sv = (v == null) ? null : v.toString();

            if (sv != null && sv.contains("\n") && !sv.contains("\r")) {
                sv = sv.replaceAll("\n", "\r\n\t");
            }

            httppost.addHeader(entry.getKey(), sv);
        }

        //---------------

        System.out.println("Sending to [" + path + "] [" + message + "]");

        ResponseHandler<String> responseHandler = new BasicResponseHandler();

        HttpClient httpclient = new DefaultHttpClient();
        String responseBody = httpclient.execute(httppost, responseHandler);

        System.out.println("Sent to [" + path + "] [" + asString(httppost) + "]");

        //---------------

        System.out.println("Received from [" + path + "] [" + responseBody + "]");

        httpclient.getConnectionManager().shutdown();

        return responseBody;
    }

    protected static String asString(HttpPost httpPost) {
        StringBuilder builder = new StringBuilder();

        builder.append(httpPost.getURI());
        builder.append("\n");

        Header[] headers = httpPost.getAllHeaders();
        for (Header header : headers) {
            builder.append("Header [");
            builder.append(header.getName());
            builder.append(": ");
            builder.append(header.getValue());
            builder.append("]\n");
        }

        return builder.toString();
    }

    @Override
    public String disconnect() throws Exception {
        System.out.println("Disconnecting from [" + url + "]");

        System.out.println("Disconnected from [" + url + "]");

        return "<" + XPathHelper.RESPONSE_XML_NODE_ROOT + ">"
                + "<" + XPathHelper.RESPONSE_XML_NODE_SUCCESS + ">Success</" + XPathHelper.RESPONSE_XML_NODE_SUCCESS +
                ">"
                + "</" + XPathHelper.RESPONSE_XML_NODE_ROOT + ">";
    }
}
