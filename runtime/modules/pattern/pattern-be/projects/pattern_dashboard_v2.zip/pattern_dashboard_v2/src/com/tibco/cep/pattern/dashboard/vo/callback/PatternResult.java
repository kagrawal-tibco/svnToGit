/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callback;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ajayapra
 */
public class PatternResult {

    protected String patternUri;
    protected String patternInstanceName;
    protected String correlationId;
    protected String success;
    protected List<EventInfo> eventInfos;

    public PatternResult() {
        this.eventInfos = new LinkedList<EventInfo>();
    }

    public PatternResult(String patternUri, String patternInstanceName,
            String correlationId, String success) {
        this.patternUri = patternUri;
        this.patternInstanceName = patternInstanceName;
        this.correlationId = correlationId;
        this.success = success;

        this.eventInfos = new LinkedList<EventInfo>();
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public List<EventInfo> getEventInfos() {
        return eventInfos;
    }

    public void addEventInfos(EventInfo eventInfo) {
        this.eventInfos.add(eventInfo);
    }

    public void setEventInfos(List<EventInfo> eventInfos) {
        this.eventInfos = eventInfos;
    }

    public String getPatternInstanceName() {
        return patternInstanceName;
    }

    public void setPatternInstanceName(String patternInstanceName) {
        this.patternInstanceName = patternInstanceName;
    }

    public String getPatternUri() {
        return patternUri;
    }

    public void setPatternUri(String patternUri) {
        this.patternUri = patternUri;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public static class EventInfo {

        protected String id;
        protected String extId;

        public EventInfo() {
        }

        public EventInfo(String id, String extId) {
            this.id = id;
            this.extId = extId;
        }

        public String getExtId() {
            return extId;
        }

        public void setExtId(String extId) {
            this.extId = extId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }
}
