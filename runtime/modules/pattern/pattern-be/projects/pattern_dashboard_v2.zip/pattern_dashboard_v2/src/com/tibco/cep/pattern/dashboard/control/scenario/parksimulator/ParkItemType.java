/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.parksimulator;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author ajayapra
 */
public enum ParkItemType {

    PAPA("Papa bear"),
    MAMA("Mama bear"),
    BABY("Baby bear"),
    GRANDMA("Grandma"),
    WOLF("Big bad wolf"),
    HOOD("Red riding hood"),
    GOLDILOCKS("Goldilocks"),
    CLOSE("Close");
    protected static Map<String, ParkItemType> reverseMap = Collections.synchronizedMap(new HashMap<String, ParkItemType>());
    protected String name;

    private ParkItemType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static ParkItemType getItem(String name) {
        if (reverseMap.isEmpty()) {
            for (ParkItemType item : values()) {
                reverseMap.put(item.getName(), item);
            }
        }

        return reverseMap.get(name);
    }

    @Override
    public String toString() {
        return getName();
    }
}
