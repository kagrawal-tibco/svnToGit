/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.pattern;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.ui.pattern.PatternView;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import com.tibco.cep.pattern.dashboard.vo.VoRoot;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployPatternRequestSender.MessageSendSequence;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployedPattern;
import com.tibco.cep.pattern.dashboard.vo.pattern.UndeployPatternRequest;
import com.tibco.cep.pattern.dashboard.vo.pattern.UndeployPatternRequestSender;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.util.Iterator;
import javax.swing.AbstractAction;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author ajayapra
 */
public class UndeployPatternFormAction extends AbstractAction {

    protected PatternView patternView;

    public UndeployPatternFormAction(PatternView patternView) {
        this.patternView = patternView;
    }

    public void actionPerformed(ActionEvent e) {
        AsyncJob asyncJob = new AsyncJob();

        //---------------

        Registry registry = Registry.getRegistry();
        AsyncExecutor asyncExecutor = registry.getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected class AsyncJob implements Runnable {

        protected AnimatedJob animatedJob;

        public AsyncJob() {
            this.animatedJob = new AnimatedJob("Preparing");
        }

        protected void updateUI() {
            try {
                SwingUtilities.invokeAndWait(new Runnable() {

                    public void run() {
                        Container container = patternView.getParent();
                        if (container instanceof JTabbedPane == false) {
                            return;
                        }

                        JTabbedPane tabbedPane = (JTabbedPane) container;

                        int count = tabbedPane.getTabCount();

                        for (int i = 0; i < count; i++) {
                            Component tabComponent = tabbedPane.getComponentAt(i);
                            if (tabComponent == patternView) {
                                tabbedPane.setTitleAt(i, "<new>");
                            }
                        }
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void run() {
            animatedJob.start();

            Registry registry = Registry.getRegistry();
            EndPoint endPoint = registry.getVoRoot().getEndPoint();
            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before undeploying the pattern");

                    Helper.$sleep(1200);
                } else {
                    VoRoot voRoot = Registry.getRegistry().getVoRoot();

                    if (voRoot.isStarted() == false) {
                        animatedJob.updateProgress("Please start the service before undeploying the pattern");

                        Helper.$sleep(1200);
                    } else {
                        DeployedPattern deployedPattern = patternView.getDeployedPattern();
                        if (deployedPattern == null) {
                            animatedJob.updateProgress("Please deploy the pattern before undeploying it");

                            Helper.$sleep(1200);
                        } else {
                            UndeployPatternRequest request = new UndeployPatternRequest();
                            request.setDeployedPattern(deployedPattern);

                            UndeployPatternRequestSender requestSender = new UndeployPatternRequestSender(request, endPoint);

                            MessageSendSequence[] sequence = MessageSendSequence.values();
                            int i = 0;
                            Iterator<Object> iterator = requestSender.prepareSender();

                            for (; iterator.hasNext();) {
                                Object message = iterator.next();

                                if (message instanceof ExternalErrorEvent) {
                                    ExternalErrorEvent responseMessage = (ExternalErrorEvent) message;

                                    animatedJob.updateProgress(responseMessage.getComment());

                                    throw responseMessage.getException();
                                } else if (message instanceof ExternalResponseEvent) {
                                    ExternalResponseEvent responseMessage = (ExternalResponseEvent) message;

                                    if (sequence[i] == MessageSendSequence.FINAL) {
                                        deployedPattern = (DeployedPattern) responseMessage.getResponse();
                                    } else {
                                        animatedJob.updateProgress(responseMessage.getComment());
                                    }
                                } else {
                                    animatedJob.updateProgress(message.toString());
                                }

                                i++;

                                Helper.$sleep(300);
                            }

                            //--------------

                            updateUI();

                            //--------------

                            patternView.setDeployedPattern(null);

                            voRoot.removeDeployedPattern(deployedPattern.getKey());

                            //--------------

                            //todo Update the Home/DeployedPatterns list
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred while deploying the pattern [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
