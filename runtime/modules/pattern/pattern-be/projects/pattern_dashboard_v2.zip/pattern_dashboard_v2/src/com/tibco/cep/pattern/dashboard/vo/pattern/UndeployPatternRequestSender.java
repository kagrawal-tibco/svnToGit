/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.pattern;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ControlRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.RequestSender;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public class UndeployPatternRequestSender implements RequestSender {

    public static enum MessageSendSequence {

        ONE("Undeploying pattern "),
        TWO("Undeployed pattern "),
        THREE("Unregistering pattern "),
        FOUR("Unregistered pattern "),
        FINAL("Success"),
        ERROR("Error occurred ");
        protected String message;

        private MessageSendSequence(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
    protected UndeployPatternRequest request;
    protected EndPoint endPoint;

    public UndeployPatternRequestSender(UndeployPatternRequest request, EndPoint endPoint) {
        this.request = request;
        this.endPoint = endPoint;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public UndeployPatternRequest getRequest() {
        return request;
    }

    public Iterator<Object> prepareSender() {
        return new Sender();
    }

    protected class Sender implements Iterator<Object> {

        protected LinkedHashMap<MessageSendSequence, Object> work;
        protected Iterator<Entry<MessageSendSequence, Object>> workIterator;
        protected DeployedPattern deployedPattern;

        public Sender() {
            this.work = new LinkedHashMap<MessageSendSequence, Object>();

            this.deployedPattern = request.getDeployedPattern();

            //------------

            work.put(MessageSendSequence.ONE, null);

            work.put(MessageSendSequence.TWO, null);

            work.put(MessageSendSequence.THREE, null);

            work.put(MessageSendSequence.FOUR, null);

            work.put(MessageSendSequence.FINAL, null);

            //------------

            workIterator = work.entrySet().iterator();
        }

        public boolean hasNext() {
            return workIterator.hasNext();
        }

        public Object next() {
            Entry<MessageSendSequence, Object> entry = workIterator.next();

            switch (entry.getKey()) {
                case ONE:
                    break;

                case TWO: {
                    //todo Skip if already undeployed.

                    String patternName = XPathHelper.wrapCData(deployedPattern.getInstanceName());
                    String undeployPatternXml = "<undeploy><pattern-instance-name>" + patternName + "</pattern-instance-name></undeploy>";

                    ExternalRequestEvent requestMessage = new ControlRequestEvent("undeploy pattern", undeployPatternXml);

                    try {
                        String response = endPoint.sendAndReceive(requestMessage);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + err[0], err[0], requestMessage, e);
                        }

                        return new ExternalResponseEvent(entry.getKey().getMessage() + "[" + deployedPattern.getInstanceName() + "]",
                                deployedPattern.getInstanceName(), requestMessage);
                    } catch (Exception ex) {
                        ex.printStackTrace();

                        return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + ex.getMessage(), ex.getMessage(), requestMessage, ex);
                    }
                }

                case THREE:
                    break;

                case FOUR: {
                    String unregisterPatternXml = "<unregister><pattern-uri>" + deployedPattern.getUri() + "</pattern-uri></unregister>";

                    ExternalRequestEvent requestMessage = new ControlRequestEvent("unregister pattern", unregisterPatternXml);
                    try {
                        String response = endPoint.sendAndReceive(requestMessage);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(entry.getKey().getMessage(), err[0], requestMessage, e);
                        }

                        return new ExternalResponseEvent(entry.getKey().getMessage(), response, requestMessage);
                    } catch (Exception ex) {
                        //todo On error rollback registration.

                        ex.printStackTrace();

                        return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + ex.getMessage(), ex.getMessage(), requestMessage, ex);
                    }
                }

                case FINAL: {
                    return new ExternalResponseEvent(entry.getKey().getMessage(), deployedPattern);
                }
            }

            return entry.getKey().getMessage();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
