/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.ui.common;

/**
 *
 * @author ajayapra
 */
public class CustomInfiniteProgressPanel extends InfiniteProgressPanel {

    @Override
    public void start() {
        super.start();
    }

    @Override
    public void stop() {
        super.stop();
    }
}
