/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.pattern;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.callback.CallbackService;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ControlRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.RequestSender;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public class DeployPatternRequestSender implements RequestSender {

    public static enum MessageSendSequence {

        ONE("Registering pattern "),
        TWO("Registered pattern "),
        THREE("Deploying pattern "),
        FOUR("Deployed pattern "),
        FINAL("Success"),
        ERROR("Error occurred ");
        protected String message;

        private MessageSendSequence(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
    protected DeployPatternRequest request;
    protected EndPoint endPoint;

    public DeployPatternRequestSender(DeployPatternRequest request, EndPoint endPoint) {
        this.request = request;
        this.endPoint = endPoint;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public DeployPatternRequest getRequest() {
        return request;
    }

    public Iterator<Object> prepareSender() {
        return new Sender();
    }

    protected class Sender implements Iterator<Object> {

        protected LinkedHashMap<MessageSendSequence, Object> work;
        protected Iterator<Entry<MessageSendSequence, Object>> workIterator;
        protected DeployedPattern deployedPattern;

        public Sender() {
            this.work = new LinkedHashMap<MessageSendSequence, Object>();

            this.deployedPattern = new DeployedPattern();
            this.deployedPattern.setInstanceName(request.getNickName());
            this.deployedPattern.setKey(request.getNickName());
            this.deployedPattern.setPatternRequest(request);

            //------------

            work.put(MessageSendSequence.ONE, null);

            work.put(MessageSendSequence.TWO, null);

            work.put(MessageSendSequence.THREE, null);

            work.put(MessageSendSequence.FOUR, null);

            work.put(MessageSendSequence.FINAL, null);

            //------------

            workIterator = work.entrySet().iterator();
        }

        public boolean hasNext() {
            return workIterator.hasNext();
        }

        public Object next() {
            Entry<MessageSendSequence, Object> entry = workIterator.next();

            switch (entry.getKey()) {
                case ONE:
                    break;

                case TWO: {
                    String patternString = XPathHelper.wrapCData(request.getPattern());
                    String registerPatternXml = "<register><pattern>" + patternString + "</pattern></register>";

                    ExternalRequestEvent requestMessage = new ControlRequestEvent("register pattern", registerPatternXml);

                    try {
                        String response = endPoint.sendAndReceive(requestMessage);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + err[0], err[0], requestMessage, e);
                        }

                        String patternURI = XPathHelper.query(response, "//pattern-uri");
                        deployedPattern.setUri(patternURI);

                        return new ExternalResponseEvent(entry.getKey().getMessage() + "[" + patternURI + "]", patternURI, requestMessage);
                    } catch (Exception ex) {
                        ex.printStackTrace();

                        return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + ex.getMessage(), ex.getMessage(), requestMessage, ex);
                    }
                }

                case THREE:
                    break;

                case FOUR: {
                    String nickName = request.getNickName();

                    CallbackService callbackService = Registry.getRegistry().getCallbackService();
                    String closureCSV = callbackService.makeClosureCSV(deployedPattern.getUri());

                    closureCSV = XPathHelper.wrapCData(closureCSV);

                    String deployPatternXml = "<deploy>"
                            + "<pattern-uri>" + deployedPattern.getUri() + "</pattern-uri>"
                            + "<pattern-closure>" + closureCSV + "</pattern-closure>"
                            + "<pattern-instance-name>" + nickName + "</pattern-instance-name>"
                            + "</deploy>";

                    ExternalRequestEvent requestMessage = new ControlRequestEvent("deploy pattern", deployPatternXml);
                    try {
                        String response = endPoint.sendAndReceive(requestMessage);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(entry.getKey().getMessage(), err[0], requestMessage, e);
                        }

                        return new ExternalResponseEvent(entry.getKey().getMessage(), response, requestMessage);
                    } catch (Exception ex) {
                        //todo On error rollback registration.

                        ex.printStackTrace();

                        return new ExternalErrorEvent(MessageSendSequence.ERROR.getMessage() + ex.getMessage(), ex.getMessage(), requestMessage, ex);
                    }
                }

                case FINAL: {
                    return new ExternalResponseEvent(entry.getKey().getMessage(), deployedPattern);
                }
            }

            return entry.getKey().getMessage();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
