/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.callsimulator;

/**
 *
 * @author ajayapra
 */
public enum CallEventType {

    PLACE_CALL("Call placed"),
    END_CALL("Call ended"),
    DROP_CALL("Call dropped");
    protected String name;

    private CallEventType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static CallEventType[] getPairEnds() {
        return new CallEventType[]{END_CALL, DROP_CALL};
    }

    @Override
    public String toString() {
        return getName();
    }
}
