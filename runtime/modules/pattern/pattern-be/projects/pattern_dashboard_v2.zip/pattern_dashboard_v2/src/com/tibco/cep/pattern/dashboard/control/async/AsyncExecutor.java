/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.async;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 *
 * @author ajayapra
 */
public class AsyncExecutor {

    protected ExecutorService executorService;

    public AsyncExecutor() {
    }

    public void start() {
        executorService = Executors.newFixedThreadPool(2);
    }

    public <T> Future<T> submit(Callable<T> task) {
        return executorService.submit(task);
    }

    public Future<?> submit(Runnable task) {    	
        return executorService.submit(task);
    }

    public void stop() {
        executorService.shutdownNow();
    }
}
