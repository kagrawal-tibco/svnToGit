package com.tibco.cep.pattern.dashboard.control.home;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import com.tibco.cep.pattern.dashboard.Application;
import com.tibco.cep.pattern.dashboard.ui.PatterndashboardAboutBox;
import com.tibco.cep.pattern.dashboard.ui.PatterndashboardView;

public class ShowAboutBoxAction extends AbstractAction {
	private static final long serialVersionUID = 1L;
	private final PatterndashboardView view;
	private PatterndashboardAboutBox aboutBox;
	
	public ShowAboutBoxAction(PatterndashboardView view) {    		
		this.view = view;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
        if (aboutBox == null) {            
            aboutBox = new PatterndashboardAboutBox(view);
            aboutBox.setLocationRelativeTo(view);
        }
        Application.getInstance().show(aboutBox);			
	}
	
}