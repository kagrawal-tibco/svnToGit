/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.pattern;

import com.tibco.cep.pattern.dashboard.ui.pattern.PatternView;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JTabbedPane;

/**
 *
 * @author ajayapra
 */
public class NewPatternAction extends AbstractAction {

    protected JTabbedPane targetTabbedPane;

    public NewPatternAction(JTabbedPane targetTabbedPane) {
        this.targetTabbedPane = targetTabbedPane;
    }

    public void actionPerformed(ActionEvent e) {
        System.out.println("Adding new pattern tab");

        PatternView patternView = new PatternView();
        targetTabbedPane.addTab("<new>", patternView);
        targetTabbedPane.setSelectedComponent(patternView);
        patternView.requestFocusInWindow();

        System.out.println("Added new pattern tab");
    }
}
