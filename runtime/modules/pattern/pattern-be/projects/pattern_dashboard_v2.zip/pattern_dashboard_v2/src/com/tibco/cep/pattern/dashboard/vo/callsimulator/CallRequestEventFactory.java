/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.scenario.callsimulator.CallEventType;
import com.tibco.cep.pattern.dashboard.util.UUIDService;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ajayapra
 */
public class CallRequestEventFactory {

    public List<AbstractCallRequestEvent> create(CallSimulatorRequest request) {
        UUIDService uuidService = Registry.getRegistry().getUuidService();

        String phNum = request.getPhNum();
        LinkedList<AbstractCallRequestEvent> list = new LinkedList<AbstractCallRequestEvent>();

        for (CallEventType callEventType : request.getCallEventTypes()) {
            String extId = uuidService.nextUUID("callsim-" + callEventType.name().toLowerCase() + "-" + phNum);

            switch (callEventType) {
                case PLACE_CALL: {
                    CallPlacedRequestEvent callPlacedRE = new CallPlacedRequestEvent(extId, phNum);
                    list.add(callPlacedRE);

                    break;
                }

                case DROP_CALL: {
                    CallDroppedRequestEvent callDroppedRE = new CallDroppedRequestEvent(extId, phNum);
                    list.add(callDroppedRE);

                    break;
                }

                case END_CALL: {
                    CallEndedRequestEvent callEndedRE = new CallEndedRequestEvent(extId, phNum);
                    list.add(callEndedRE);

                    break;
                }

                default: {
                    throw new IllegalArgumentException(callEventType.getName() + " is invalid for a 'call' type");
                }
            }
        }

        return list;
    }
}
