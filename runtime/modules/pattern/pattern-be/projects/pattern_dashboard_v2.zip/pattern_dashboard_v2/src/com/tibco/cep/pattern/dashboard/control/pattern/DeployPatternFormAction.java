/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.pattern;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.ui.pattern.PatternView;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import com.tibco.cep.pattern.dashboard.vo.VoRoot;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployPatternRequest;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployPatternRequestSender;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployPatternRequestSender.MessageSendSequence;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployedPattern;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.util.Iterator;
import javax.swing.AbstractAction;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author ajayapra
 */
public class DeployPatternFormAction extends AbstractAction {

    protected PatternView patternView;
    protected JTextArea patternTextArea;
    protected JTextField nickNameField;

    public DeployPatternFormAction(PatternView patternView, JTextArea patternTextArea, JTextField nickNameField) {
        this.patternView = patternView;
        this.patternTextArea = patternTextArea;
        this.nickNameField = nickNameField;
    }

    public void actionPerformed(ActionEvent e) {
        String nickName = nickNameField.getText();

        if (nickName == null || nickName.trim().length() == 0) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            nickNameField.setText(null);

            nickNameField.requestFocusInWindow();

            statusLabelService.writeMessage("Please provide a valid nick name");

            return;
        }

        //---------------

        String patternString = patternTextArea.getText();

        if (patternString == null || patternString.trim().length() == 0) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            patternTextArea.setText(null);

            patternTextArea.requestFocusInWindow();

            statusLabelService.writeMessage("Please provide a valid pattern");

            return;
        }

        //---------------      

        DeployPatternRequest request = new DeployPatternRequest();

        request.setNickName((nickName == null) ? null : nickName.trim());

        String nickNamePattern = "%nickname%";
        String newPatternString = patternString.replaceAll(nickNamePattern, nickName);
        if (newPatternString.equals(patternString) == false) {
            System.out.println("Replaced " + nickNamePattern + ". New pattern string is: " + newPatternString);

            patternString = newPatternString;
        }

        request.setPattern(patternString);

        AsyncJob asyncJob = new AsyncJob(request);

        //---------------

        Registry registry = Registry.getRegistry();
        AsyncExecutor asyncExecutor = registry.getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected class AsyncJob implements Runnable {

        protected DeployPatternRequest request;
        protected AnimatedJob animatedJob;

        public AsyncJob(DeployPatternRequest request) {
            this.request = request;
            this.animatedJob = new AnimatedJob("Preparing");
        }

        protected void updateTabTitle(final String title) {
            Container container = patternView.getParent();
            if (container instanceof JTabbedPane == false) {
                return;
            }

            final JTabbedPane tabbedPane = (JTabbedPane) container;

            try {
                SwingUtilities.invokeAndWait(new Runnable() {

                    public void run() {
                        int count = tabbedPane.getTabCount();

                        for (int i = 0; i < count; i++) {
                            Component tabComponent = tabbedPane.getComponentAt(i);
                            if (tabComponent == patternView) {
                                tabbedPane.setTitleAt(i, title);
                            }
                        }
                    }
                });
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void run() {
            animatedJob.start();

            Registry registry = Registry.getRegistry();
            EndPoint endPoint = registry.getVoRoot().getEndPoint();
            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before deploying the pattern");

                    Helper.$sleep(1200);
                } else {
                    VoRoot voRoot = Registry.getRegistry().getVoRoot();

                    if (voRoot.isStarted() == false) {
                        animatedJob.updateProgress("Please start the service before deploying the pattern");

                        Helper.$sleep(1200);
                    } else {
                        DeployedPattern deployedPattern = patternView.getDeployedPattern();
                        if (deployedPattern != null) {
                            animatedJob.updateProgress("Please undeploy the current pattern first");

                            Helper.$sleep(1200);
                        } else {
                            DeployPatternRequestSender requestSender = new DeployPatternRequestSender(request, endPoint);

                            Iterator<Object> iterator = requestSender.prepareSender();

                            MessageSendSequence[] sequence = MessageSendSequence.values();
                            int i = 0;
                            for (; iterator.hasNext();) {
                                Object message = iterator.next();

                                if (message instanceof ExternalErrorEvent) {
                                    ExternalErrorEvent responseMessage = (ExternalErrorEvent) message;

                                    animatedJob.updateProgress(responseMessage.getComment());

                                    throw responseMessage.getException();
                                } else if (message instanceof ExternalResponseEvent) {
                                    ExternalResponseEvent responseMessage = (ExternalResponseEvent) message;

                                    if (sequence[i] == MessageSendSequence.FINAL) {
                                        deployedPattern = (DeployedPattern) responseMessage.getResponse();
                                    } else {
                                        animatedJob.updateProgress(responseMessage.getComment());
                                    }
                                } else {
                                    animatedJob.updateProgress(message.toString());
                                }

                                i++;

                                Helper.$sleep(300);
                            }

                            //--------------

                            updateTabTitle(deployedPattern.getInstanceName());

                            //--------------

                            patternView.setDeployedPattern(deployedPattern);

                            registry.getVoRoot().addDeployedPattern(deployedPattern);

                            //--------------

                            //todo Update the Home/DeployedPatterns list
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred while deploying the pattern [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
