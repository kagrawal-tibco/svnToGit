/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

/**
 *
 * @author ajayapra
 */
public class ControlRequestEvent extends ExternalRequestEvent {

    public static final String PATH = "/Channels/HTTPChannel/Control";
    public static final String HEADER_NM = "ControlRequestEvent";
    public static final String HEADER_NS = "www.tibco.com/be/ontology/Events/" + HEADER_NM;
    public static final String FIELD_ACTION = "action";
    public static final String FIELD_DATA = "data";

    public ControlRequestEvent(String action, String data) {
        setTargetPath(PATH);
        addHeader("_nm_", HEADER_NM);
        addHeader("_ns_", HEADER_NS);

        addParameter(FIELD_ACTION, action);
        addParameter(FIELD_DATA, data);
    }

    public void setAction(String value) {
        addParameter(FIELD_ACTION, value);
    }

    public void setData(String value) {
        addParameter(FIELD_DATA, value);
    }
}
