/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.async;

import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.ui.common.CustomInfiniteProgressPanel;
import com.tibco.cep.pattern.dashboard.util.CallFromUiThread;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;

/**
 *
 * @author ajayapra
 */
public class AnimatedJob {

    protected String title;
    protected StatusMessageService statusLabelService;
    protected CustomInfiniteProgressPanel infiniteProgressPanel;

    /**
     * @param title
     */
    @CallFromUiThread
    public AnimatedJob(String title) {
        this.title = title;
        this.statusLabelService = Registry.getRegistry().getStatusMessageService();

        this.infiniteProgressPanel = new CustomInfiniteProgressPanel();
    }

    public void start() {
    	infiniteProgressPanel.start();
    }

    public void updateProgress(final String message) {
        try {
            SwingUtilities.invokeAndWait(new Runnable() {

                public void run() {
                    statusLabelService.writeMessage(message);
                }
            });
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
        }
    }

    /**
     *
     * @param restFocusOn Can be null.
     */
    public void stop(final JComponent restFocusOn) {
        infiniteProgressPanel.stop();

        if (restFocusOn == null) {
            return;
        }

        try {
            SwingUtilities.invokeAndWait(new Runnable() {

                public void run() {
                    restFocusOn.requestFocusInWindow();
                }
            });
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        } catch (InvocationTargetException ex) {
            ex.printStackTrace();
        }
    }
}
