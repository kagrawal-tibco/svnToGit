/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.pattern;

/**
 *
 * @author ajayapra
 */
public enum ResultTemplate {

    CALL_SIM_STD("standard-call-simulator"),
    PARK_SIM_STD("standard-park-simulator");
    protected String name;

    private ResultTemplate(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return getName();
    }
}
