/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.home;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 *
 * @author ajayapra
 */
public class DisconnectAction extends AbstractAction {

    public void actionPerformed(ActionEvent e) {
        Registry registry = Registry.getRegistry();
        EndPoint endPoint = registry.getVoRoot().getEndPoint();

        AsyncJob asyncJob = new AsyncJob(endPoint);

        AsyncExecutor asyncExecutor = registry.getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected static class AsyncJob implements Runnable {

        protected EndPoint endPoint;
        protected AnimatedJob animatedJob;

        public AsyncJob(EndPoint endPoint) {
            this.endPoint = endPoint;
            this.animatedJob = new AnimatedJob("Disconnecting");
        }

        public void run() {
            animatedJob.start();

            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before disconnecting");

                    Helper.$sleep(1200);
                } else {
                    String response = endPoint.disconnect();

                    String[] err = XPathHelper.getIfError(response);
                    if (err != null) {
                        throw new Exception(err[0] + "::" + err[1]);
                    } else {
                        Registry.getRegistry().getVoRoot().setEndPoint(null);

                        animatedJob.updateProgress("Disconnected");

                        Helper.$appendToAppTitle(null);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred while disconnecting");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
