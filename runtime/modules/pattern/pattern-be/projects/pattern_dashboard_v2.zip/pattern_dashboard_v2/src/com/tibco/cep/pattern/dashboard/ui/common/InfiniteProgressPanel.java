package com.tibco.cep.pattern.dashboard.ui.common;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.tibco.cep.pattern.dashboard.Application;

public class InfiniteProgressPanel {

	private final GlassPane glasspane;

	public InfiniteProgressPanel() {
		glasspane = new GlassPane();
	}

	public void start() {
		glasspane.start();
	}

	public void stop() {
		glasspane.stop();
	}

	private class GlassPane extends JComponent {
		private static final long serialVersionUID = 1L;
		private JFrame container;
		private Cursor defaultCursor;
		Color color;

		protected void paintComponent(Graphics g) {
			g.setColor(color);
			g.fillRect(0, 0, container.getWidth(), container.getHeight());
		}

		public GlassPane() {
			this.container = Application.getMainFrame();
			Color gray = Color.WHITE;
			float[] colorComponents = new float[3];
			gray.getRGBColorComponents(colorComponents);
			color = new Color(colorComponents[0], colorComponents[1],
					colorComponents[2], 0.40f);
			container.getRootPane().setGlassPane(this);
		}

		public void start() {
			defaultCursor = container.getCursor();
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {					
					container.setCursor(Cursor
							.getPredefinedCursor(Cursor.WAIT_CURSOR));
					container.getRootPane().getGlassPane().setVisible(true);
				}
			});
		}

		public void stop() {
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					container.setCursor(defaultCursor);
					container.getRootPane().getGlassPane().setVisible(false);
				}
			});
		}
	}
}
