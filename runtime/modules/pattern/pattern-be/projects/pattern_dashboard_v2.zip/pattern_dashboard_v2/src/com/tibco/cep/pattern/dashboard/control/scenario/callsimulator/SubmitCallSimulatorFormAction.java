/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.scenario.callsimulator;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import com.tibco.cep.pattern.dashboard.vo.callsimulator.CallSimulatorRequest;
import com.tibco.cep.pattern.dashboard.vo.callsimulator.CallSimulatorRequestSender;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.AbstractAction;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListModel;

/**
 *
 * @author ajayapra
 */
public class SubmitCallSimulatorFormAction extends AbstractAction {

    protected JTextField phNumTextField;
    protected JList sequenceList;

    public SubmitCallSimulatorFormAction(JTextField phNumTextField, JList sequenceList) {
        this.phNumTextField = phNumTextField;
        this.sequenceList = sequenceList;
    }

    protected boolean checkList(CallSimulatorRequest request) {
        StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

        ListModel listModel = sequenceList.getModel();
        int size = listModel.getSize();

        //--------------

        if (size == 0) {
            statusLabelService.writeMessage("Please add a few (pairs) event types");

            return false;
        }

        //--------------

        if (size % 2 == 1) {
            statusLabelService.writeMessage("Warning: Please add pairs of event types");
        }

        //--------------

        LinkedList<CallEventType> callEventList = new LinkedList<CallEventType>();

        CallEventType pairStart = null;
        for (int i = 0; i < size; i++) {
            CallEventType callEventType = (CallEventType) listModel.getElementAt(i);

            if (pairStart == null) {
                if (callEventType != CallEventType.PLACE_CALL) {
                    statusLabelService.writeMessage("Warning: Every pair has to start with [" + CallEventType.PLACE_CALL + "]");

                    sequenceList.setSelectedIndex(i);
                    sequenceList.ensureIndexIsVisible(i);
                } else {
                    pairStart = callEventType;
                }
            } else {
                if (callEventType == CallEventType.PLACE_CALL) {
                    statusLabelService.writeMessage("Warning: Every pair has to start with [" + CallEventType.PLACE_CALL
                            + "] and end with one of " + Arrays.asList(CallEventType.getPairEnds()));

                    sequenceList.setSelectedIndex(i);
                    sequenceList.ensureIndexIsVisible(i);
                }

                pairStart = null;
            }

            callEventList.add(callEventType);
        }

        //--------------

        request.setCallEventTypes(callEventList);

        return true;
    }

    public void actionPerformed(ActionEvent e) {
        String phNum = phNumTextField.getText();
        if (phNum == null || phNum.trim().length() == 0) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            phNumTextField.setText(null);

            phNumTextField.requestFocusInWindow();

            statusLabelService.writeMessage("Please provide a phone number");

            return;
        }

        CallSimulatorRequest request = new CallSimulatorRequest();

        request.setPhNum(phNum);

        //--------------

        if (checkList(request) == false) {
            return;
        }

        //--------------

        AsyncJob asyncJob = new AsyncJob(request);

        AsyncExecutor asyncExecutor = Registry.getRegistry().getAsyncExecutor();
        asyncExecutor.submit(asyncJob);
    }

    protected static class AsyncJob implements Runnable {

        protected CallSimulatorRequest request;
        protected AnimatedJob animatedJob;

        public AsyncJob(CallSimulatorRequest request) {
            this.request = request;
            this.animatedJob = new AnimatedJob("Preparing");
        }

        public void run() {
            animatedJob.start();

            Registry registry = Registry.getRegistry();
            EndPoint endPoint = registry.getVoRoot().getEndPoint();
            try {
                if (endPoint == null) {
                    animatedJob.updateProgress("Please connect to the engine before submitting");

                    Helper.$sleep(1200);
                } else {
                    long pauseMillis = Helper.$getEventSentPauseMillis();

                    CallSimulatorRequestSender requestSender = new CallSimulatorRequestSender(request, endPoint, pauseMillis);

                    Iterator<Object> iterator = requestSender.prepareSender();

                    for (; iterator.hasNext();) {
                        Object message = iterator.next();

                        if (message instanceof ExternalErrorEvent) {
                            ExternalErrorEvent responseMessage = (ExternalErrorEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());

                            throw responseMessage.getException();
                        } else if (message instanceof ExternalResponseEvent) {
                            ExternalResponseEvent responseMessage = (ExternalResponseEvent) message;

                            animatedJob.updateProgress(responseMessage.getComment());
                        } else {
                            animatedJob.updateProgress(message.toString());
                        }

                        Helper.$sleep(300);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
