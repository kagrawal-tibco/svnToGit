/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.parksimulator;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.RequestSender;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public class ParkSimulatorRequestSender implements RequestSender {

    protected ParkSimulatorRequest request;
    protected EndPoint endPoint;
    protected long intervalMillis;

    public ParkSimulatorRequestSender(ParkSimulatorRequest request, EndPoint endPoint, long intervalMillis) {
        this.request = request;
        this.endPoint = endPoint;
        this.intervalMillis = intervalMillis;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public ParkSimulatorRequest getRequest() {
        return request;
    }

    public Iterator<Object> prepareSender() {
        return new Sender();
    }

    protected class Sender implements Iterator<Object> {

        protected LinkedHashMap<String, Object> work;
        protected Iterator<Entry<String, Object>> workIterator;

        public Sender() {
            this.work = new LinkedHashMap<String, Object>();

            String areaId = request.getParkAreaId();

            work.put("Processing park area sequence for [" + areaId + "]", null);

            //------------

            ParkRequestEventFactory parkRequestEventFactory = new ParkRequestEventFactory();
            List<AbstractParkRequestEvent> listOfREs = parkRequestEventFactory.create(request);

            AbstractParkRequestEvent prev = null;

            for (AbstractParkRequestEvent abstractParkRequestEvent : listOfREs) {
                if (prev instanceof ParkItemEnteredRequestEvent
                        && abstractParkRequestEvent instanceof ParkItemLeftRequestEvent) {
                    work.put("Paused for [" + intervalMillis + "] milliseconds after "
                            + abstractParkRequestEvent.getExtId(), intervalMillis);
                } else if (prev instanceof ParkItemLeftRequestEvent
                        && abstractParkRequestEvent instanceof ParkClosedRequestEvent) {
                    work.put("Paused for [" + intervalMillis + "] milliseconds after "
                            + abstractParkRequestEvent.getExtId(), intervalMillis);
                }

                work.put("Sending [" + abstractParkRequestEvent.getClass().getSimpleName()
                        + "] with extId [" + abstractParkRequestEvent.getExtId() + "]", null);

                work.put("Sent [" + abstractParkRequestEvent.getClass().getSimpleName()
                        + "] with extId [" + abstractParkRequestEvent.getExtId() + "]", abstractParkRequestEvent);

                prev = abstractParkRequestEvent;
            }

            //------------

            work.put("Processed park area sequence for [" + areaId + "]", null);

            //------------

            workIterator = work.entrySet().iterator();
        }

        public boolean hasNext() {
            return workIterator.hasNext();
        }

        public Object next() {
            Entry<String, Object> entry = workIterator.next();

            Object value = entry.getValue();
            if (value != null) {
                if (value instanceof Long) {
                    try {
                        Thread.sleep(intervalMillis);
                    } catch (InterruptedException ex) {
                    }
                } else {
                    AbstractParkRequestEvent apre = (AbstractParkRequestEvent) value;

                    try {
                        String response = endPoint.sendAndReceive(apre);

                        String[] err = XPathHelper.getIfError(response);
                        if (err != null) {
                            Exception e = new Exception(err[0] + "::" + err[1]);

                            return new ExternalErrorEvent(entry.getKey(), err[0], apre, e);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();

                        return new ExternalErrorEvent(entry.getKey(), ex.getMessage(), apre, ex);
                    }
                }
            }

            return entry.getKey();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
