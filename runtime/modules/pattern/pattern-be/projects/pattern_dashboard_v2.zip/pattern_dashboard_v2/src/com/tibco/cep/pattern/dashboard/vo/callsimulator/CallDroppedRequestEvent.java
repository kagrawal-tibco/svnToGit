/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

/**
 *
 * @author ajayapra
 */
public class CallDroppedRequestEvent extends AbstractCallRequestEvent {

    public CallDroppedRequestEvent(String extId, String phNumber) {
        super(extId, phNumber);
    }

    @Override
    protected String getNM() {
        return "CallDropped";
    }
}
