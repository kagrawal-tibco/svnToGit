/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

/**
 *
 * @author ajayapra
 */
public abstract class AbstractExternalRequestEvent extends ExternalRequestEvent {

    public static final String HEADER_NM = "_nm_";
    public static final String HEADER_NS = "_ns_";
    public static final String HEADER_EXT_ID = "_extId_";

    /**
     * Calls {@link #getNM()} and {@link #getNS()}.
     * @param targetPath
     * @param extId
     */
    public AbstractExternalRequestEvent(String targetPath, String extId) {
        setTargetPath(targetPath);

        addHeader(HEADER_NM, getNM());
        addHeader(HEADER_NS, getNS());
        addHeader(HEADER_EXT_ID, extId);
    }

    protected abstract String getNM();

    protected abstract String getNS();

    public String getExtId() {
        return (String) headers.get(HEADER_EXT_ID);
    }
}
