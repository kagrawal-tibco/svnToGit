/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.home;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import com.tibco.cep.pattern.dashboard.vo.ControlRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalErrorEvent;
import com.tibco.cep.pattern.dashboard.vo.ExternalRequestEvent;
import com.tibco.cep.pattern.dashboard.vo.RequestSender;
import com.tibco.cep.pattern.dashboard.vo.ExternalResponseEvent;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

/**
 *
 * @author ajayapra
 */
public class ServiceStopRequestSender implements RequestSender {

    protected ServiceStopRequest request;
    protected EndPoint endPoint;

    public ServiceStopRequestSender(ServiceStopRequest request, EndPoint endPoint) {
        this.request = request;
        this.endPoint = endPoint;
    }

    public EndPoint getEndPoint() {
        return endPoint;
    }

    public ServiceStopRequest getRequest() {
        return request;
    }

    public Iterator<Object> prepareSender() {
        return new Sender();
    }

    protected class Sender implements Iterator<Object> {

        protected LinkedHashMap<String, Object> work;
        protected Iterator<Entry<String, Object>> workIterator;

        public Sender() {
            this.work = new LinkedHashMap<String, Object>();

            //------------

            work.put("Sending request", null);

            work.put("Sent request", new ControlRequestEvent("stop epl service", null));

            work.put("Stopped service", null);

            //------------

            workIterator = work.entrySet().iterator();
        }

        public boolean hasNext() {
            return workIterator.hasNext();
        }

        public Object next() {
            Entry<String, Object> entry = workIterator.next();

            Object value = entry.getValue();
            if (value != null && value instanceof ExternalRequestEvent) {
                ExternalRequestEvent requestMessage = (ExternalRequestEvent) value;

                try {
                    String response = endPoint.sendAndReceive(requestMessage);

                    String[] err = XPathHelper.getIfError(response);
                    if (err != null) {
                        Exception e = new Exception(err[0] + "::" + err[1]);

                        return new ExternalErrorEvent("Error occurred " + err[0], err[0], requestMessage, e);
                    }

                    return new ExternalResponseEvent(entry.getKey(), response, requestMessage);
                } catch (Exception ex) {
                    ex.printStackTrace();

                    return new ExternalErrorEvent(entry.getKey(), ex.getMessage(), requestMessage, ex);
                }
            }

            return entry.getKey();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }
    }
}
