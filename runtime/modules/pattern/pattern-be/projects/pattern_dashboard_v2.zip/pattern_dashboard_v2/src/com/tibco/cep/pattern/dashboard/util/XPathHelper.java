/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.util;

import java.io.StringReader;
import javax.xml.namespace.QName;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.xml.sax.InputSource;

/**
 *
 * @author ajayapra
 */
public class XPathHelper {

    public static final String RESPONSE_XML_NODE_ROOT = "response";
    public static final String RESPONSE_XML_NODE_SUCCESS = "success";
    public static final String RESPONSE_XML_NODE_ERROR = "error";
    public static final String RESPONSE_XPATH_ERROR_MSG = "/" + RESPONSE_XML_NODE_ROOT + "/" + RESPONSE_XML_NODE_ERROR + "/msg/text()";
    public static final String RESPONSE_XPATH_ERROR_TRACE = "/" + RESPONSE_XML_NODE_ROOT + "/" + RESPONSE_XML_NODE_ERROR + "/trace/text()";
    public static final String RESPONSE_XPATH_SUCCESS_MSG = "/" + RESPONSE_XML_NODE_ROOT + "/" + RESPONSE_XML_NODE_SUCCESS + "/text()";

    public static String wrapCData(String string) {
        return "<![CDATA[" + string + "]]>";
    }

    /**
     *
     * @param xml
     * @param xPathQuery
     * @param returnType See {@link XPathConstants}
     * @return
     * @throws XPathExpressionException
     */
    public static Object query(String xml, String xPathQuery, QName returnType) throws XPathExpressionException {
        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();

        XPathExpression expression = xpath.compile(xPathQuery);

        return expression.evaluate(new InputSource(new StringReader(xml)), returnType);
    }

    public static String query(String xml, String xPathQuery) throws XPathExpressionException {
        return (String) query(xml, xPathQuery, XPathConstants.STRING);
    }

    public static boolean isSuccess(String xml) throws XPathExpressionException {
        String[] error = getIfError(xml);

        return (error == null);
    }

    public static String getIfSuccess(String xml) throws XPathExpressionException {
        String[] error = getIfError(xml);

        if (error == null) {
            return query(xml, RESPONSE_XPATH_SUCCESS_MSG);
        }

        return null;
    }

    /**
     *
     * @param xml
     * @return null if not error. Otherwise String[] with [0]=message, [1]=trace.
     * @throws XPathExpressionException
     */
    public static String[] getIfError(String xml) throws XPathExpressionException {
        String root = query(xml, "local-name(/" + RESPONSE_XML_NODE_ROOT + "/*)");

        if (root.equalsIgnoreCase(RESPONSE_XML_NODE_ERROR)) {
            String msg = query(xml, RESPONSE_XPATH_ERROR_MSG);
            String trace = query(xml, RESPONSE_XPATH_ERROR_TRACE);

            return new String[]{msg, trace};
        }

        return null;
    }
}
