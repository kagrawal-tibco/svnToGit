/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.pattern;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.ui.pattern.PatternView;
import com.tibco.cep.pattern.dashboard.vo.pattern.DeployedPattern;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author ajayapra
 */
public class ClearPatternFormAction extends AbstractAction {

    protected PatternView patternView;
    protected JTextArea patternTextArea;
    protected JTextField nickNameField;

    public ClearPatternFormAction(PatternView patternView, JTextArea patternTextArea, JTextField nickNameField) {
        this.patternView = patternView;
        this.patternTextArea = patternTextArea;
        this.nickNameField = nickNameField;
    }

    public void actionPerformed(ActionEvent e) {
        DeployedPattern deployedPattern = patternView.getDeployedPattern();
        if (deployedPattern != null) {
            StatusMessageService statusMessageService = Registry.getRegistry().getStatusMessageService();

            statusMessageService.writeMessage("Please undeploy the current pattern first");

            return;
        }

        patternTextArea.setText(null);

        nickNameField.setText(null);
    }
}
