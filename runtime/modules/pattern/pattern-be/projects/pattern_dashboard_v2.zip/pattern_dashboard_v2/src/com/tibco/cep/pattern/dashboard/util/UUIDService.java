/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.util;

import java.util.Formatter;
import java.util.concurrent.atomic.AtomicLong;

/**
 *
 * @author ajayapra
 */
public class UUIDService {

    protected AtomicLong counter;

    public UUIDService() {
        this.counter = new AtomicLong();
    }

    /**
     *
     * @param name Uses the name as the prefix to generate a uuid.
     * @return
     */
    public String nextUUID(String name) {
        long l = counter.incrementAndGet();

        String s = name + "-" + new Formatter().format("%010d", l);

        return s;
    }
}
