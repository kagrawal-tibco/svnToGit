/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.result;

import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.model.result.ResultTableModel;
import com.tibco.cep.pattern.dashboard.ui.result.PatternResultView;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 *
 * @author ajayapra
 */
public class ClearPatternResultsAction extends AbstractAction {

    public ClearPatternResultsAction() {
    }

    public void actionPerformed(ActionEvent e) {
        ResultTableModel tableModel = Registry.getRegistry().getModelRoot().getResultTableModel();

        int rowCountAtTheBeginning = tableModel.getRowCount();

        for (int i = rowCountAtTheBeginning; i > 0; i--) {
            try {
                int latestLastRow = tableModel.getRowCount() - 1;
                if (latestLastRow < 0) {
                    return;
                }

                tableModel.removeRow(latestLastRow);
            } catch (Exception ex) {
                //Someone must've added a new row or deleted more than once.
                return;
            }
        }
    }
}
