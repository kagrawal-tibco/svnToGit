/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo;

import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import java.util.Iterator;

/**
 *
 * @author ajayapra
 */
public interface RequestSender {

    Request getRequest();

    EndPoint getEndPoint();

    Iterator<Object> prepareSender();
}
