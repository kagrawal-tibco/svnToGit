/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.home;

import com.tibco.cep.pattern.dashboard.control.Helper;
import com.tibco.cep.pattern.dashboard.control.Registry;
import com.tibco.cep.pattern.dashboard.control.StatusMessageService;
import com.tibco.cep.pattern.dashboard.control.async.AnimatedJob;
import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.transport.EndPoint;
import com.tibco.cep.pattern.dashboard.util.XPathHelper;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JTextField;

/**
 *
 * @author ajayapra
 */
public class ConnectAction extends AbstractAction {

    protected JTextField serviceUrlTextField;

    public ConnectAction(JTextField serviceUrlTextField) {
        this.serviceUrlTextField = serviceUrlTextField;
    }

    public void actionPerformed(ActionEvent e) {
        String urlString = serviceUrlTextField.getText();
        if (urlString == null || (urlString = urlString.trim()).length() == 0) {
            StatusMessageService statusLabelService = Registry.getRegistry().getStatusMessageService();

            serviceUrlTextField.setText(null);

            serviceUrlTextField.requestFocusInWindow();

            statusLabelService.writeMessage("Please provide a valid address");

            return;
        }

        //----------------

        AsyncJob asyncJob = new AsyncJob(urlString);

        AsyncExecutor asyncExecutor = Registry.getRegistry().getAsyncExecutor();
        asyncExecutor.submit(asyncJob);       
    }

    protected static class AsyncJob implements Runnable {

        protected String address;
        protected AnimatedJob animatedJob;

        public AsyncJob(String address) {
            this.address = address;

            String msg = "Connecting to [" + address + "]";
            this.animatedJob = new AnimatedJob(msg);
        }

        public void run() {
            animatedJob.start();
            Registry registry = Registry.getRegistry();
            EndPoint endPoint = registry.getEndPointCreator().create(address);
            try {
                String response = endPoint.connect();

                String[] err = XPathHelper.getIfError(response);
                if (err != null) {
                    throw new Exception(err[0] + "::" + err[1]);
                }

                //------------------

                registry.getVoRoot().setEndPoint(endPoint);

                String msg = "Connected to [" + address + "]";
                animatedJob.updateProgress(msg);

                Helper.$appendToAppTitle(msg);
            } catch (Exception ex) {
                ex.printStackTrace();

                animatedJob.updateProgress("Error occurred while connecting to [" + address + "] [" + ex.getMessage() + "]");

                Helper.$sleep(1200);
            }

            animatedJob.stop(null);
        }
    }
}
