/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.pattern;

import com.tibco.cep.pattern.dashboard.vo.Request;

/**
 *
 * @author ajayapra
 */
public class UndeployPatternRequest implements Request {

    protected DeployedPattern deployedPattern;

    public UndeployPatternRequest() {
    }

    public DeployedPattern getDeployedPattern() {
        return deployedPattern;
    }

    public void setDeployedPattern(DeployedPattern deployedPattern) {
        this.deployedPattern = deployedPattern;
    }
}
