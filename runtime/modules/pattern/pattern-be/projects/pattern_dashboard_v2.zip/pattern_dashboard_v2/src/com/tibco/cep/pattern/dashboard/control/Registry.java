/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control;

import com.tibco.cep.pattern.dashboard.control.async.AsyncExecutor;
import com.tibco.cep.pattern.dashboard.control.callback.CallbackService;
import com.tibco.cep.pattern.dashboard.control.transport.EndPointCreator;
import com.tibco.cep.pattern.dashboard.model.ModelRoot;
import com.tibco.cep.pattern.dashboard.util.UUIDService;
import com.tibco.cep.pattern.dashboard.vo.VoRoot;

/**
 *
 * @author ajayapra
 */
public class Registry {

    protected static final Registry SINGLETON = new Registry();
    protected VoRoot voRoot;
    protected ModelRoot modelRoot;
    protected AsyncExecutor asyncExecutor;
    protected StatusMessageService statusMessageService;
    protected EndPointCreator endPointCreator;
    protected UUIDService uuidService;
    protected CallbackService callbackService;

    protected Registry() {
        this.voRoot = new VoRoot();
        this.modelRoot = new ModelRoot();
        this.asyncExecutor = new AsyncExecutor();
        this.statusMessageService = new StatusMessageService();
        this.endPointCreator = new EndPointCreator();
        this.uuidService = new UUIDService();
        this.callbackService = new CallbackService();
    }

    public static Registry getRegistry() {
        return SINGLETON;
    }

    public void start() {
        asyncExecutor.start();
        callbackService.start();
    }

    public VoRoot getVoRoot() {
        return voRoot;
    }

    public ModelRoot getModelRoot() {
        return modelRoot;
    }

    public AsyncExecutor getAsyncExecutor() {
        return asyncExecutor;
    }

    public StatusMessageService getStatusMessageService() {
        return statusMessageService;
    }

    public EndPointCreator getEndPointCreator() {
        return endPointCreator;
    }

    public UUIDService getUuidService() {
        return uuidService;
    }

    public CallbackService getCallbackService() {
        return callbackService;
    }

    public void stop() {
        callbackService.stop();
        asyncExecutor.stop();
    }
}
