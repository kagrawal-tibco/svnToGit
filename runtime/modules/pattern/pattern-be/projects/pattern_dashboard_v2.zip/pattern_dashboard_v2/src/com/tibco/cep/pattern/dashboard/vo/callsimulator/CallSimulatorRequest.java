/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.vo.callsimulator;

import com.tibco.cep.pattern.dashboard.control.scenario.callsimulator.CallEventType;
import com.tibco.cep.pattern.dashboard.vo.Request;
import java.util.List;

/**
 *
 * @author ajayapra
 */
public class CallSimulatorRequest implements Request {

    protected String phNum;
    protected List<CallEventType> callEventTypes;

    public CallSimulatorRequest() {
    }

    public String getPhNum() {
        return phNum;
    }

    public void setPhNum(String phNum) {
        this.phNum = phNum;
    }

    public List<CallEventType> getCallEventTypes() {
        return callEventTypes;
    }

    public void setCallEventTypes(List<CallEventType> callEventTypes) {
        this.callEventTypes = callEventTypes;
    }
}
