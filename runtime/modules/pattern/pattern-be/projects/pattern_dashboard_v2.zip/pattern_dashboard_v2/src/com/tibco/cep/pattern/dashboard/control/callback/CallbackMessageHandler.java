/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tibco.cep.pattern.dashboard.control.callback;

/**
 *
 * @author ajayapra
 */
public interface CallbackMessageHandler {

    Object onMessage(byte[] bytes);
}
